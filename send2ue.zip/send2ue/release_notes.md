## Minor Changes
* Fixed rotations on instance assets extension.
  * [602](https://github.com/EpicGames/BlenderTools/issues/602)
  * [621](https://github.com/EpicGames/BlenderTools/issues/621)
* Fixed transformation bug with use object origin option.
  * [610](https://github.com/EpicGames/BlenderTools/issues/610)

## Special Thanks
@abhiraaid

## Tests Passing On
* Blender `3.3`, `3.5` (installed from blender.org)
* Unreal `5.1`, `5.2`
